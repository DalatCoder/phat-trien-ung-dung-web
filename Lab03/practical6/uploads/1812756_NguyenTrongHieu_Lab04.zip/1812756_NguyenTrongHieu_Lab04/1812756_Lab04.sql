-- a)
SELECT SUBSTRING(products.productName, 1, 20) AS 'Tieu De San Pham'
FROM products

-- b) 
SELECT CONCAT(employees.lastName, ' ', employees.firstName) AS FullName, employees.jobTitle
FROM employees

-- c)
SELECT
    customers.customerName,
    CONCAT(
        customers.addressLine1,
        ' - ',
        customers.city,
        ' *** ',
        customers.`state`,
        ' --- ',
        customers.country
    ) AS CustomerFullAddress
FROM
    customers
WHERE
    customers.`state` IS NOT NULL
    AND customers.addressLine1 IS NOT NULL
    AND customers.country IS NOT NULL

-- d)
SELECT REPLACE(lower(productlines.productLine), 'cars', 'xe hoi')
FROM productlines


-- e)
SELECT
    IF (
        e_origin.reportsTo IS NOT NULL,
        (
            SELECT
                CONCAT(e_child.lastName, ' ', e_child.firstName)
            FROM
                employees AS e_child
            WHERE
                e_origin.reportsTo = e_child.employeeNumber
        ),
        'No'
    ) AS ManagerName,
    e_origin.*
FROM
    employees AS e_origin


-- f)
SELECT
    IF (
        customers.salesRepEmployeeNumber IS NULL,
        'Chua co',
        ( SELECT CONCAT(employees.lastName, ' ', employees.firstName) FROM employees WHERE employees.employeeNumber = customers.salesRepEmployeeNumber )
    ) AS EmployeeFullName,
    customers.customerName,
    customers.salesRepEmployeeNumber
FROM
    customers


-- g)
SELECT SUM( IF (customers.country = 'France', 1, 0) ) AS CustomerLiveInFrance FROM customers


-- h)
SELECT
    SUM(IF(customers.addressLine2 IS NULL, 1, 0)) AS 'NumberOfCustomerWithoutAddressLine2'
FROM
    customers


-- i)
SELECT
    *
FROM
    orders
WHERE
    orders.shippedDate < SUBDATE('2005-5-17', INTERVAL 2 MONTH)


-- j)
SELECT DATEDIFF(orders.shippedDate, orders.requiredDate) AS 'ThoiGianGiaoHang', orders.*
FROM orders
WHERE orders.shippedDate IS NOT NULL
ORDER BY ThoiGianGiaoHang ASC
LIMIT 5


-- k)
SELECT * 
FROM orders
WHERE orders.orderDate > ADDDATE('2005/3/2', INTERVAL 1 MONTH)


-- l)
SELECT * 
FROM orders
WHERE orders.orderDate < ADDDATE('2005/4/1', INTERVAL 2 WEEK)


-- m)
SELECT
    *
FROM
    orders
WHERE
    MONTH(orders.orderDate) = 4
    AND YEAR(orders.orderDate) = 2005
    AND orders.shippedDate IS NULL


-- n)
SELECT
    CONCAT(
        customers.contactLastName,
        ' ',
        customers.contactFirstName
    ) AS CustomerFullName
FROM
    orders
    INNER JOIN customers ON customers.customerNumber = customers.customerNumber
WHERE
    orders.status = 'Cancelled'
    AND orders.orderDate > ADDDATE('2004/5/8', INTERVAL 8 MONTH)
